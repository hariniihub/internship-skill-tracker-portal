from django.db import models

# Create your models here.
from django.db import models
from django.contrib.auth.models import User

class Skill(models.Model):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name


class Student(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    department = models.CharField(max_length=100)
    year = models.IntegerField()
    skills = models.ManyToManyField(Skill)

    def __str__(self):
        return self.user.username


class Internship(models.Model):
    company_name = models.CharField(max_length=100)
    role = models.CharField(max_length=100)
    required_skills = models.TextField()
    stipend = models.IntegerField()
    deadline = models.DateField()

    def __str__(self):
        return self.role


class Application(models.Model):
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Accepted', 'Accepted'),
        ('Rejected', 'Rejected'),
    ]

    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    internship = models.ForeignKey(Internship, on_delete=models.CASCADE)
    resume = models.FileField(upload_to='resumes/')
    applied_date = models.DateTimeField(auto_now_add=True)
    status = models.CharField(max_length=20, choices=STATUS_CHOICES)

    def __str__(self):
        return f"{self.student} - {self.internship}"