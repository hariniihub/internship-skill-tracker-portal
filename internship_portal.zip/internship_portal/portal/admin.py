from django.contrib import admin

# Register your models here.
from django.contrib import admin
from .models import *

admin.site.register(Student)
admin.site.register(Skill)
admin.site.register(Internship)
admin.site.register(Application)